/* formas básicas para la detección de eventos JS
Primera forma: de define el evento en la eqtiqueta de HTML asociada a la función que se desea ejecutar cuando ocurre dicho evento
*/
function clic() {
  alert("Este evento fue disparador al hacer click en el botón");
}

function over() {
  alert("El mouse ha ingresado al campo del boton");
}

function out() {
  alert("El mouse ha salido del campo del boton");
}

function otro_click(){
  alert("esto fue disparado por el div");
}
/* Segunda forma: el mejor procedimiento para el menejo de eventos consiste utilizar listener, aqui se debe tener presente los conceptos de bubbling y capture que básicamente hacen referencia a la forma en la que se propaga el evento en el DOM*/
document.getElementById("mi_btn").addEventListener("click", clic, true);

/*Ejemplo de bubbling y capture */

document.getElementById("mi_div").addEventListener("click", otro_click, false)

/*Al modificar el tercer parámetro true/false del listener modifico el orden de la ejecución, es decir el orden en que los elementos detectan los eventos*/