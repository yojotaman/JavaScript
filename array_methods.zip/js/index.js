var arreglo=[2,5,1,10,20];
var arreglo_2=["p","j"];

arreglo.sort(); // ordena de manera alfabética
arreglo_2.sort();
console.log(arreglo);
console.log(arreglo_2);

// para ordenar por valor 

function ordenar(a,b){
  return a - b;
}

arreglo.sort(ordenar);
console.log(arreglo);

// invertir el orden del arreglo
arreglo.reverse();
arreglo_2.reverse();
console.log(arreglo);
console.log(arreglo_2);

// convertir una cadena en un arreglo

var arreglo_3 = "a,b,c,2";
console.log(arreglo_3);
arreglo_3=arreglo_3.split(",");
console.log(arreglo_3);

// pasar de un arreglo a una cadena

arreglo_4=arreglo_3.join();// se puede definir el separador deseado
console.log(arreglo_4);