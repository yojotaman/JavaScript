
/*Se pueden declarar de dos maneras*/

var arreglo = [20,10,5]; // Con los corchetes rectagulares - forma recomendada
// segunda forma
// var arreglo = new Array(20); 

console.log(arreglo[2]);
// longitud de un arreglo
console.log(arreglo.length);
// colocar un elemento al final del arreglo
arreglo.push(9);
console.log(arreglo);
/*  coloca un elemento al inicio de un areglo, unshift no reemplaza el primer elemento, sólo añade un elemento al inicio sin modificar los restante */
arreglo.unshift(4);
console.log(arreglo);
/*utilizando shift, lo que haría es eliminar el primer elemento del arreglo*/
arreglo.shift();
console.log(arreglo);
/*el inverso de shift es pop y elimina el último elemento del arreglo  */
arreglo.pop();
console.log(arreglo);

/*iteración co arreglos  */
var arreglo_2 = [1,2,3,4];

for(var i=0; i<=arreglo_2.length; i++){  // forma no optimizada
  console.log(arreglo_2[i]);
}
for(var i = arreglo_2.length; i>=0; i--){
  console.log(arreglo_2[i]);
}

var i = arreglo_2.length;
for(;i>=0;i--){
  console.log(arreglo_2[i]);
}