 // obtienen elementos con el nombre de la clase 

/* var div = document.getElementById("mi_div");
div.classList.add("mi_clase");
*/

/*var div = document.getElementsByClassName("mi_clase");
console.log(div);
*/

var div = document.getElementsByTagName("div");
console.log(div);