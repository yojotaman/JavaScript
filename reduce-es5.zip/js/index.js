/* Metodo para ejecutar también sobre los arreglos */

var letras = ["h", "o", "l", "a"];

/* en este punto queremos unir todos los elementos del arreglo en una sola cadena (podemos Hacer esto de dos maneras) */

// primera forma: empleando el método join
console.log(letras.join(""));

// Segunda forma: usando reduce
/*  
var palabra=letras.reduce(function(valor_anterior_retornado, valor_actual,index,arreglo) {
  return valor_anterior_retornado + valor_actual;
});

*/
var palabra=letras.reduce(function(ant, act,ind,arr) {
  return ant + act;
});

console.log(palabra);

// un siguiente ejemplo con un arreglo de números
var numeros = [10,20,30,40];

var suma=numeros.reduce(function(ant, act,ind,arr){
  return ant+act;
});
console.log(suma);

//Por último podemos hacer esta misma operación utilizando un ciclo for tradicional

var suma_2 = 0;
for(i=0;i<numeros.length;i++){
  suma_2 +=numeros[i];
}
console.log(suma_2);