var numeros = [1,5,6,8];

/*El objetivo es que pada uno de los elementos del arreglo se convierta en su cuadrado  */


// solución sin MAP

var cuadrados = [];
for (var i = numeros.length; i>0; i--){
  var numero = numeros[i -1];
  cuadrados.push(Math.pow(numero,2));
}
console.log(numeros.length)
console.log(cuadrados);


// solución con MAP
numeros.map(function(elemento){
  return Math.pow(elemento,2)
});
console.log(cuadrados);

// numero.map(callback);