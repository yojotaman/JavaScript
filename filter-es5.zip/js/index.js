/*En ocasiones es necesario poder crear un nuevo arreglo con el resultado arrojado por alguna función, para esto es de utilidad usar filter

Veamos en que consiste lo que necesitamos
*/
/*vamos a construir un programa que genere un arreglo que contenga sólo los números pares del arreglo inicial */


// solución si filter
var numeros = [10, 2, 3, 5, 9, 20, 22,8];
var pares = [];
for (var i = numeros.length; i >= 0; i--) {
  var num= numeros[i];
  if (num%2 == 0){
    pares.push(num);
  }
}

console.log(pares);

// forma optimizada con filter
var pares_2 = numeros.filter(function(numero){
  return numero % 2===0;
});
console.log(pares_2);