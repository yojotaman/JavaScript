//número máximo
var max = 100;
//número mínimo
var min = 1;
// número aleatorio
var aleatorio = parseInt(Math.random() * ((max - min) + min));
console.log(aleatorio);

var mensaje = "ingresa un número para divinar el número aleatorio"
while (true) {
  var num_user = prompt(mensaje, "0");
  num_user = parseInt(num_user);
  if (num_user === 0) {
    break;
  } else if (num_user === aleatorio)
    alert("Ganaste, has adivinado el número aleatorio");

  else if (num_user > aleatorio) {
    mensaje = "Lo siento, el número aleatorio es menor que el número que ingresaste";
  } else if (num_user < aleatorio) {
    mensaje = "Lo siento, el número aleatorio es mayor que el número que ingresaste"
  }

}